package com.company;

public interface House {
    public String getDescription();
    public String getCost();
}
